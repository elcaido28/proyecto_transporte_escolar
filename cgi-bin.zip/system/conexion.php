<?php
// 	$con=mysqli_connect("localhost", "ago13_root", "13_Agosto_root", "ago13_transporte_escolar");
	date_default_timezone_set('America/Guayaquil');
?>
