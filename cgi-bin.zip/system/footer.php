
<footer class="main-footer">

	<strong>Copyright &copy; 2020.</strong>

	Todos los derechos a Cooperativa 13 de Agosto.


</footer>

<script src="../vistas/js/plantilla.js"></script>
<script src="../vistas/js/usuarios.js"></script>
<script src="../vistas/js/categorias.js"></script>
<script src="../vistas/js/productos.js"></script>
<script src="../vistas/js/clientes.js"></script>
<script src="../vistas/js/ventas.js"></script>
<script src="../vistas/js/reportes.js"></script>

</body>
</html>
