import {closestByAttribute} from './ToolsDom';

export function SetSelectedAdapter(selectElement){

    // var isRtl = false;
    // var e = closestByAttribute(element,"dir","rtl");
    // if (e)
    //     isRtl = true;
    // return isRtl;
}