<?php
	$con=mysqli_connect("localhost", "root", "root", "transporte_escolar");
	date_default_timezone_set('America/Guayaquil');
?>
