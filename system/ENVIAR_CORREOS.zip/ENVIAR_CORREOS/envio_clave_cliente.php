<?php
require 'ENVIAR_CORREOS/PHPMailer.php';
require 'ENVIAR_CORREOS/SMTP.php';
require 'ENVIAR_CORREOS/Exception.php';
require 'ENVIAR_CORREOS/OAuth.php';

// $nombre= $_POST['name'];
// $email= $_POST['email'];
// $asunto= $_POST['subject'];
// $mensaje= $_POST['message'];


$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
/*
Enable SMTP debugging
0 = off (for production use)
1 = client messages
2 = client and server messages
*/
$mail->SMTPDebug = 0;
$mail->Host = 'SMTP.Office365.com';
$mail->Port = 587;
$mail->SMTPSecure = 'STARTTLS';
$mail->SMTPAuth = true;
$mail->Username = "coop13deagosto@hotmail.com";
$mail->Password = "silvita66";
$mail->setFrom('coop13deagosto@hotmail.com', 'Pagina Web');
$mail->addAddress('bryane.lb13@hotmail.com', 'Lab. Loly De bryan'); // $correo_cli  .$nombre
$mail->Subject = 'Consulta Cliente';
$mail->Body = "<div style='padding:5px;'> <br> Nombre de Cliente : bryan"."<br><br>Correo: bryan@hotmail"."  <br><br>  Asunto: asunyo"." <br> <br>   Mensaje: djndj ncjds dsjcsd csdc sdc sdjc ksd kcs"." <br> </div>";
//$mail->addAttachment('/levox2.png', 'My uploaded file'); <img src='/levox2.png' width='150' height='110'>
$mail->CharSet = 'UTF-8'; // Con esto ya funcionan los acentos
$mail->IsHTML(true);

if (!$mail->send())
{
	echo "Error al enviar el E-Mail: ".$mail->ErrorInfo;
}
else
{
	// header("Location:../contact.php");
  echo "si envio correo correctamente";
}
?>
